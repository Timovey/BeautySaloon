﻿namespace BeautySaloonBusinessLogic.Enums
{
    public enum DistributionStatus
    {
        Выдана = 0,
        Используется = 1,
        Возвращена = 2
    }
}
