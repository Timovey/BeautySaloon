﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace BeautySaloonBusinessLogic.ViewModels
{
    public class DistributionViewModel
    {
        public int Id { get; set; }

        [DisplayName("Дата выдачи")]
        public DateTime IssueDate { get; set; }

        public Dictionary<int, (string, int)> DistributionCosmetics { get; set; }
    }
}
