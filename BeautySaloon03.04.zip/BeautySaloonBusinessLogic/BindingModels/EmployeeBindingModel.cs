﻿namespace BeautySaloonBusinessLogic.BindingModels
{
    public class EmployeeBindingModel
    {
        public int? Id { get; set; }

        public string F_Name { get; set; }

        public string L_Name { get; set; }

        public string Login { get; set; }

        public string Password { get; set; }

        public string EMail { get; set; }

        public string PhoneNumber { get; set; }
    }
}
