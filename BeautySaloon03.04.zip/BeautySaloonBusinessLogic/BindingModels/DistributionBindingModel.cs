﻿using System;
using System.Collections.Generic;

namespace BeautySaloonBusinessLogic.BindingModels
{
    public class DistributionBindingModel
    {
        public int? Id { get; set; }

        public DateTime IssueDate { get; set; }

        public Dictionary<int, (string, int)> DistributionCosmetics { get; set; }
    }
}
