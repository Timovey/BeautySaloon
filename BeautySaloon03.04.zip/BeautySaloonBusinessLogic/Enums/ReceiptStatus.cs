﻿namespace BeautySaloonBusinessLogic.Enums
{
    public enum ReceiptStatus
    {
        Создан = 0,
        Оплачен = 1,
        Готов = 2
    }
}
